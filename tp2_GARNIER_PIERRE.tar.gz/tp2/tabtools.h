float **alloctab(int dim1, int dim2);
int **alloctabint(int dim1, int dim2);
void freetab(void *ptr);