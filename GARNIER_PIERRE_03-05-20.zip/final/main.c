#include"mesh_tools.h"
#include"tabtools.h"
#include"felfunc.h"
#include"fcaltools.h"
#include<stdio.h>
#include<stdlib.h>

int main(int argc, char const *argv[])
{
    char * meshfile = "car1x1t_1";
    char * numreffile = "numref";

    //allocations à 100000 pour voir si ces valeurs s'immiscent qqpart
    int type = 100000;
    int elemCount = 100000;
    int nodeCount = 100000;
    int elemNodeCount = 100000;
    int elemEdgeCount = 100000;

	int nRefDom = 100000;
    int nbRefD0 = 100000;
    int nbRefD1 = 100000;
    int nbRefF1 = 100000; 
    
	int *numRefD0 = NULL;
    int *numRefD1 = NULL;
    int *numRefF1 = NULL;

    float **coord = NULL;
    float **coorEl = NULL;

    int **ngnel = NULL;
    int **nRefAr = NULL;

    int *NuDElem = NULL;
    float *SMbrElem = NULL;
    float *uDElem = NULL;
    float **MatElem = NULL;

    if(lecfima(meshfile, &type, &nodeCount, &coord, &elemCount, &ngnel, &elemNodeCount, &elemEdgeCount, &nRefAr)
	   &&
	   lecNumRef(numreffile, &nRefDom, &nbRefD0, &numRefD0, &nbRefD1, &numRefD1, &nbRefF1, &numRefF1)
       ){
        printf("Les données sont en mémoire\n");

        SMbrElem = malloc(elemNodeCount*sizeof(float));
        NuDElem = malloc(elemNodeCount*sizeof(int));
        uDElem = malloc(elemNodeCount*sizeof(float));
        MatElem = alloctab(elemNodeCount, elemNodeCount);
        coorEl = malloc(elemNodeCount*sizeof(float*));

        printf("%p \n", coord[0]);

        for(int i=0; i<nodeCount; i++){
            printf("%d \n", i);
            printf("%f %f\n", coord[i][0], coord[i][1]);
        }

        for(int i=0; i<elemCount; i++){
            selectPts(elemNodeCount, ngnel[i], coord, coorEl);
            cal1Elem(nRefDom, type, elemNodeCount, elemEdgeCount,
                     nbRefD0, numRefD0, nbRefD1, numRefD1, nbRefF1, numRefF1,
                     nRefAr[i], coorEl,
                     MatElem, SMbrElem, NuDElem, uDElem);
            impCalEl(i, elemNodeCount, type, MatElem, SMbrElem, NuDElem, uDElem);
        }

        free(SMbrElem);
        free(NuDElem);
        free(uDElem);
        free(coorEl);
        freetab(MatElem);

    } else {
        printf("Erreur lors de la lecture du meshfile ou du numreffile, verifier le formatage\n");
    }

    freetab(coord);
    freetab(ngnel);
    freetab(nRefAr);

    free(numRefD0);
    free(numRefD1);
    free(numRefF1);

    return 0;
}