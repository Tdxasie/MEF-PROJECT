float solex(float *coor);
void CalSol(int nbLign, float **coord, float *UEX);
void CholeskyResol(int nbLign, int *Profile, float *MatrixP, float *SecMembr, float eps, float *U);
int nucas;