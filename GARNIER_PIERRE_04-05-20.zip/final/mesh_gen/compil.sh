#!/bin/bash

gcc mesh_gen.c ../tabtools.c ../mesh_tools.c -o gen
