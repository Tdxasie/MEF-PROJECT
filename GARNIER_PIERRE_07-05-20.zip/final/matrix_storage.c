#include"forfun.h"
#include<stdio.h>
#include<stdlib.h>

int exportSMD(char *filename, int nbLign, 
              float *SecMembr, int *NumDLDir, float *ValDrDir, int *firstAdLi, float *Matrix, int *colIdx,int *followingAdLi){
    
    FILE *out = NULL;
    out = fopen(filename, "wb");

    if(out != NULL){

        int format = 1; //1: SMD // 2:SMO

        fwrite(&format, sizeof(int), 1, out); //on spécifie qu'on écrit du SMD

        fwrite(&nbLign, sizeof(int), 1, out);
        fwrite(SecMembr, sizeof(float), nbLign, out);
        fwrite(NumDLDir, sizeof(int), nbLign, out);
        fwrite(ValDrDir, sizeof(float), nbLign, out);
        fwrite(firstAdLi, sizeof(int), nbLign, out);

        int nbCoef = firstAdLi[nbLign-1]-1;

        fwrite(colIdx, sizeof(int), nbCoef, out);
        fwrite(followingAdLi, sizeof(int), nbCoef, out);
        fwrite(Matrix, sizeof(float), nbLign+nbCoef, out);

        fclose(out);

    } else {
        printf("Erreur lors de l'ouverture du fichier SMD_export\n");
        return 0;
    }
    return 1;
}

int importSMD(char *filename, int *nbLign,
              float **SecMembr, int **numDlDir, float **ValDrDir, int **firstAdLi, float **Matrix, int **colIdx,int **followingAdLi){
        
    FILE *in = NULL;
    in = fopen(filename, "rb");

    if(in != NULL){

        int format;

        fread(&format, sizeof(int), 1, in);

        if (format != 1){
            printf("Erreur lors de l'import SMD, format incorrect\n");
            return 0;
        }
    
        fread(nbLign, sizeof(int), 1, in);

        *firstAdLi = calloc(*nbLign, sizeof(int));
        *SecMembr = calloc(*nbLign, sizeof(float));
        *numDlDir = calloc(*nbLign, sizeof(int));
        *ValDrDir = calloc(*nbLign, sizeof(float));

        fread(*SecMembr, sizeof(float), *nbLign, in);
        fread(*numDlDir, sizeof(int), *nbLign, in);
        fread(*ValDrDir, sizeof(float), *nbLign, in);
        fread(*firstAdLi, sizeof(int), *nbLign, in);

        int nbCoef = (*firstAdLi)[*nbLign-1]-1;

        *colIdx = calloc(nbCoef, sizeof(int));
        *followingAdLi = calloc(nbCoef, sizeof(int));
        *Matrix = calloc(*nbLign+nbCoef, sizeof(float));

        fread(*colIdx, sizeof(int), nbCoef, in);
        fread(*followingAdLi, sizeof(int), nbCoef, in);
        fread(*Matrix, sizeof(float), *nbLign+nbCoef, in);

        fclose(in);

    } else {
        printf("Erreur lors de l'ouverture du fichier SMD_export\n");
        return 0;
    }
    return 1;
}

int SMDtoSMO(char *filename, int nbLign, int *firstAdLi, int *colIdx, int *followindAdLi, int *NumDLDIR, float *ValDrDir, float *MatrixD, float *SecMembrD,
             int *firstAdLiO, int *colIdxO, float *MatrixO, float *SecMembrO){

    cdesse_(&nbLign, firstAdLi, colIdx, followindAdLi, MatrixD, SecMembrD, NumDLDIR, ValDrDir, firstAdLiO, colIdxO, MatrixO, SecMembrO);

    FILE *out = NULL;
    out = fopen(filename, "wb");

    if(out != NULL){

        int format = 2; //1: SMD // 2:SMO

        fwrite(&format, sizeof(int), 1, out); //on spécifie qu'on écrit du SMD

        fwrite(&nbLign, sizeof(int), 1, out);
        fwrite(SecMembrO, sizeof(float), nbLign, out);
        fwrite(firstAdLiO, sizeof(int), nbLign, out);

        int nbCoef = firstAdLiO[nbLign-1]-1;

        fwrite(colIdxO, sizeof(int), nbCoef, out);
        fwrite(MatrixO, sizeof(float), nbLign+nbCoef, out);

        fclose(out);

    } else {
        printf("Erreur lors de l'ouverture du fichier SMD_export\n");
        return 0;
    }

    return 1;
}

int importSMO(char *filename, int *nbLign,
              float **SecMembrO, int **firstAdLiO, float **MatrixO, int **colIdxO){
        
    FILE *in = NULL;
    in = fopen(filename, "rb");

    if(in != NULL){

        int format;

        fread(&format, sizeof(int), 1, in);

        if (format != 2){
            printf("Erreur lors de l'import SMO, format incorrect\n");
            return 0;
        }
    
        fread(nbLign, sizeof(int), 1, in);

        *SecMembrO = calloc(*nbLign, sizeof(float));
        *firstAdLiO = calloc(*nbLign, sizeof(int));

        fread(*SecMembrO, sizeof(float), *nbLign, in);
        fread(*firstAdLiO, sizeof(int), *nbLign, in);

        int nbCoef = (*firstAdLiO)[*nbLign-1]-1;

        *colIdxO = calloc(nbCoef, sizeof(int));
        *MatrixO = calloc(*nbLign+nbCoef, sizeof(float));

        fread(*colIdxO, sizeof(int), nbCoef, in);
        fread(*MatrixO, sizeof(float), *nbLign+nbCoef, in);

        fclose(in);

    } else {
        printf("Erreur lors de l'ouverture du fichier SMD_export\n");
        return 0;
    }
    return 1;
}