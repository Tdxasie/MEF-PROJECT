#include"mesh_tools.h"
#include"tabtools.h"
#include"felfunc.h"
#include"fcaltools.h"
#include"forfun.h"
#include"matrix_storage.h"
#include<stdio.h>
#include<stdlib.h>
#include<math.h>

int main()
{
    char * meshfile = "car1x1t_1";
    char * numreffile = "numref";

    int type, elemCount, elemNodeCount, elemEdgeCount;

	int nRefDom, sizeRefD0, sizeRefD1, sizeRefF1;
    
	int *numRefD0, *numRefD1, *numRefF1;

    float **nodeCoords;

    int **elemGlobalNodeIds;
    int **elemEdgeRefs;

    int nbLign, nbCoef;

    int *colIdx, *firstAdLi, *followingAdLi;
    int *colIdxO, *firstAdLiO;

    int *NumDlDir;

    float *Matrix, *SecMembr, *ValDrDir;
    float *MatrixO, *SecMembrO;

    if(lecfima(meshfile, &type, &nbLign, &nodeCoords, &elemCount, &elemGlobalNodeIds, &elemNodeCount, &elemEdgeCount, &elemEdgeRefs)
	   &&
	   lecNumRef(numreffile, &nRefDom, &sizeRefD0, &numRefD0, &sizeRefD1, &numRefD1, &sizeRefF1, &numRefF1)
       ){
        printf("Les données sont en mémoire\n");

        nbCoef = (nbLign*nbLign - nbLign)/2;

        // firstAdLi = calloc(nbLign, sizeof(int));
        // SecMembr = calloc(nbLign, sizeof(float));
        // NumDlDir = calloc(nbLign, sizeof(int));
        // ValDrDir = calloc(nbLign, sizeof(float));

        // colIdx = calloc(nbCoef, sizeof(int));
        // followingAdLi = calloc(nbCoef, sizeof(int));
        // Matrix = calloc(nbCoef+nbLign, sizeof(float));

        // assemble(type, elemCount, elemNodeCount, elemEdgeCount,
        //          elemGlobalNodeIds, nodeCoords, elemEdgeRefs,
        //          nRefDom, sizeRefD0, numRefD0, sizeRefD1, numRefD1, sizeRefF1, numRefF1,
        //          nbLign, nbCoef,
        //          SecMembr, NumDlDir, ValDrDir, firstAdLi, Matrix, colIdx, followingAdLi);
        
        // exportSMD("SMD_export", nbLign, SecMembr, NumDlDir, ValDrDir, firstAdLi, Matrix, colIdx, followingAdLi);

        // affsmd_(&nbLign, firstAdLi, colIdx, followingAdLi, Matrix, SecMembr, NumDlDir, ValDrDir);

        // free(firstAdLiO);
        // free(SecMembrO);
        // free(colIdxO);
        // free(MatrixO);

        // free(firstAdLi);
        // free(colIdx);
        // free(followingAdLi);
        // free(SecMembr);
        // free(NumDlDir);
        // free(ValDrDir);
        // free(Matrix);

        importSMD("SMD_export", &nbLign, &SecMembr, &NumDlDir, &ValDrDir, &firstAdLi, &Matrix, &colIdx, &followingAdLi);

        affsmd_(&nbLign, firstAdLi, colIdx, followingAdLi, Matrix, SecMembr, NumDlDir, ValDrDir);

        firstAdLiO = calloc(nbLign, sizeof(int));
        SecMembrO = calloc(nbLign, sizeof(float));

        nbCoef = firstAdLi[nbLign-1]-1;

        colIdxO = calloc(nbCoef, sizeof(int));
        MatrixO = calloc(nbLign+nbCoef, sizeof(float));

        SMDtoSMO("SMO_export", nbLign, firstAdLi, colIdx, followingAdLi, NumDlDir, ValDrDir, Matrix, SecMembr, firstAdLiO, colIdxO, MatrixO, SecMembrO);

        free(firstAdLiO);
        free(SecMembrO);
        free(colIdxO);
        free(MatrixO);

        importSMO("SMO_export", &nbLign, &SecMembrO, &firstAdLiO, &MatrixO, &colIdxO);

        affsmo_(&nbLign, firstAdLiO, colIdxO, MatrixO, SecMembrO);

        free(firstAdLiO);
        free(SecMembrO);
        free(colIdxO);
        free(MatrixO);

        free(firstAdLi);
        free(colIdx);
        free(followingAdLi);
        free(SecMembr);
        free(NumDlDir);
        free(ValDrDir);
        free(Matrix);

    } else {
        printf("Erreur lors de la lecture du meshfile ou du numreffile, verifier le formatage\n");
    }

    freetab(nodeCoords);
    freetab(elemGlobalNodeIds);
    freetab(elemEdgeRefs);

    free(numRefD0);
    free(numRefD1);
    free(numRefF1);

    return 0;
}