#include"mesh_tools.h"
#include"tabtools.h"
#include"felfunc.h"
#include"fcaltools.h"
#include"forfun.h"
#include<stdio.h>
#include<stdlib.h>
#include<math.h>

int main()
{
    char * meshfile = "car1x1t_1";
    char * numreffile = "numref";

    int type, elemCount, elemNodeCount, elemEdgeCount;

	int nRefDom, sizeRefD0, sizeRefD1, sizeRefF1;
    
	int *numRefD0, *numRefD1, *numRefF1;

    float **nodeCoords;

    int **elemGlobalNodeIds; //anciennement ngnel
    int **elemEdgeRefs;

    int nbLign, nbCoef;

    int *colIdx, *firstAdLi, *followingAdLi;
    int *NumDlDir;
    float *matrix, *SecMembr, *ValDrDir;

    if(lecfima(meshfile, &type, &nbLign, &nodeCoords, &elemCount, &elemGlobalNodeIds, &elemNodeCount, &elemEdgeCount, &elemEdgeRefs)
	   &&
	   lecNumRef(numreffile, &nRefDom, &sizeRefD0, &numRefD0, &sizeRefD1, &numRefD1, &sizeRefF1, &numRefF1)
       ){
        printf("Les données sont en mémoire\n");

        nbCoef = (nbLign*nbLign - nbLign)/2; //devrait dépendre du type d'élément ? 

        firstAdLi = calloc(nbLign, sizeof(int));
        colIdx = calloc(nbCoef, sizeof(int));
        followingAdLi = calloc(nbCoef, sizeof(int));
        SecMembr = calloc(nbLign, sizeof(float));
        NumDlDir = calloc(nbLign, sizeof(int));
        ValDrDir = calloc(nbLign, sizeof(float));
        matrix = calloc(nbCoef+nbLign, sizeof(float)); //tableau surdimensionné

        for(int i=0; i<nbLign; i++) NumDlDir[i] = i+1;

        assemble(type, elemCount, elemNodeCount, elemEdgeCount,
                 elemGlobalNodeIds, nodeCoords, elemEdgeRefs,
                 nRefDom, sizeRefD0, numRefD0, sizeRefD1, numRefD1, sizeRefF1, numRefF1,
                 nbLign, nbCoef,
                 SecMembr, NumDlDir, ValDrDir, firstAdLi, matrix, colIdx, followingAdLi);
        
        // exportSMD(nbLign, nbCoef, SecMembr, NumDlDir, ValDrDir, firstAdLi, matrix, colIdx, followingAdLi);

        affsmd_(&nbLign, firstAdLi, colIdx, followingAdLi, matrix, SecMembr, NumDlDir, ValDrDir);

        // importSMD(&nbLign, SecMembr, NumDlDir, ValDrDir, firstAdLi, matrix, colIdx, followingAdLi);

        // affsmd_(&nbLign, firstAdLi, colIdx, followingAdLi, matrix, SecMembr, NumDlDir, ValDrDir);

        free(firstAdLi);
        free(colIdx);
        free(followingAdLi);
        free(SecMembr);
        free(NumDlDir);
        free(ValDrDir);
        free(matrix);

    } else {
        printf("Erreur lors de la lecture du meshfile ou du numreffile, verifier le formatage\n");
    }

    freetab(nodeCoords);
    freetab(elemGlobalNodeIds);
    freetab(elemEdgeRefs);

    free(numRefD0);
    free(numRefD1);
    free(numRefF1);

    return 0;
}